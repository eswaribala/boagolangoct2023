// Package slack contains routines useful for testing slack integrations.
package slack
